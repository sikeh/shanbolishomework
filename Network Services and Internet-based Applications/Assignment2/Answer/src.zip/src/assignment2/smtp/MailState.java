package assignment2.smtp;

/**
 * Created by IntelliJ IDEA.
 * User: Shanbo Li
 * Date: Mar 31, 2008
 * Time: 1:00:49 AM
 * To change this template use File | Settings | File Templates.
 */
public enum MailState {
    INITIAL,
    PENDING,
    SEND_SUCCESSFUL,
    SEND_FAILED
}
