package assignment2.time;


import java.util.TimerTask;

import assignment2.smtp.SmtpClient;
import assignment2.smtp.Email;

/**
 * Created by IntelliJ IDEA.
 * User: Shanbo Li
 * Date: Mar 30, 2008
 * Time: 10:39:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class SendMailTask extends TimerTask {
    
    private Email email;
    private SmtpClient smtpClient = SmtpClient.getInstance();

    public SendMailTask(Email email) {
        this.email = email;
    }

    public void run() {
        smtpClient.sendAndNotifyObserver(email);
    }
}
