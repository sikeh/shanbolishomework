package assignment2.time;



import assignment2.smtp.Email;

import java.util.Timer;

/**
 * Created by IntelliJ IDEA.
 * User: Shanbo Li
 * Date: Mar 30, 2008
 * Time: 11:13:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class SendMail {
    private Timer timer;
    private MailList mailList;
    private static SendMail instance = null;

    protected SendMail() {
        timer = new Timer();
        mailList = MailList.getInstance();
    }

    public static SendMail getInstance() {
        if (instance == null) {
            instance = new SendMail();
        }
        return instance;
    }

    public void schedule(Email email) {
        mailList.add(email);
        timer.schedule(new SendMailTask(email), email.getCalendar().getTime());
    }
}
