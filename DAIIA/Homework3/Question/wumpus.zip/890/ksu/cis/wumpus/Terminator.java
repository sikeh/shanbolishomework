package ksu.cis.wumpus;

/**
 * added 20 Nov 98 - MW
 * this interface defines the things that can destroy an agent
 */
 
 public interface Terminator {
}
