package assignment1.events;

import tbn.api.Event;

/**
 * Created by IntelliJ IDEA.
 * User: Sike Huang
 * Date: 2008-1-30
 * Time: 21:38:21
 * To change this template use File | Settings | File Templates.
 */
public class FloodInitEvent implements Event {
    private final String message;

    public FloodInitEvent(String messge) {
        this.message = messge;
    }

    public String getMessage() {
        return message;
    }
}
