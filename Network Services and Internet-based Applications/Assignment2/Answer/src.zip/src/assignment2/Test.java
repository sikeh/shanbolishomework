package assignment2;

import java.net.InetAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 19, 2008
 * Time: 11:19:05 PM
 *
 * @author Shanbo Li
 */
public class Test {
    public static void main(String[] args) {
        try {
              String host = "www.java2s.com";
              byte[] message = "Java Source and Support".getBytes();

              // Get the internet address of the specified host
              InetAddress address = InetAddress.getByName("217.214.65.207");
            System.out.println(address.getAddress());

            } catch (Exception e) {
              System.err.println(e);
            }
    }
}
