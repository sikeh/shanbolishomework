package assignment2.sip;

/**
 * User: Shanbo Li
 * Date: Apr 13, 2008
 * Time: 3:24:09 PM
 *
 * @author Shanbo Li
 */
public class SipFactory {
    public static String getResponse(String[] lines) {
        StringBuilder sb = new StringBuilder();

        for (String line:lines){
            


        }



        return null;
    }

}
