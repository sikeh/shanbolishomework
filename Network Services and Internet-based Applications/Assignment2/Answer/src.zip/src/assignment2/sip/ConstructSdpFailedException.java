package assignment2.sip;

/**
 * Created by IntelliJ IDEA.
 * User: eliisho
 * Date: Apr 19, 2008
 * Time: 8:54:45 AM
 * To change this template use File | Settings | File Templates.
 */
public class ConstructSdpFailedException extends Exception{
    public ConstructSdpFailedException(String message) {
        super(message);
    }
}
