package assignment2.ui;

import java.util.Calendar;


public class DayAndTime {
  Calendar cal = Calendar.getInstance();
  public DayAndTime() {
  }

  public String getTime() {
    String t = cal.get(Calendar.HOUR_OF_DAY) + ":" + cal.get(Calendar.MINUTE) +
        ":" + cal.get(Calendar.SECOND);
    return t;
  }

}
