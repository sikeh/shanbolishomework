package assignment2.sip;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 19, 2008
 * Time: 10:20:48 AM
 *
 * @author Shanbo Li
 */
public class ConstructSipFailedException extends Exception{
    public ConstructSipFailedException(String message) {
        super(message);
    }
}
