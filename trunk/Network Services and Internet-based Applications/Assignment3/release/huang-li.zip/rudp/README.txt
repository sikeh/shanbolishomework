RELIABLE UDP

Authors:
Shanbo Li (shanbo@kth.se)
Sike Huang (sikeh@kth.se)

/src contains only source code and a make file

/vs_sender is a sample sender
/vs_receiver is a sample receiver

Example to use RUDP:
1) enter /vs_receiver, compile by make, and run
	./vs_recv -d 1124

2) enter /vs_sender, compile by make, and run
	./vs_send -d 127.0.0.1:1124 file.txt