package ksu.cis.wumpus;

/**
 * This type was created in VisualAge.
 */
public class Gold extends Thing {
}
