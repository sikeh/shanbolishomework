package tslab.exception;

/**
 * Created by IntelliJ IDEA.
 * Develop with pleasure.
 * User: Shanbo Li
 * Date: May 17, 2008
 * Time: 10:14:17 PM
 */
public class WrongInputPacketException extends Exception{
    public WrongInputPacketException(String message) {
        super(message);
    }
}
