package ksu.cis.wumpus;

public class Wall extends Thing implements Obstacle {}
