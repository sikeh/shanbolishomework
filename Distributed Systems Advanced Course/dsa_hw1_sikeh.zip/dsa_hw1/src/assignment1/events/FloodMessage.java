package assignment1.events;

import tbn.comm.mina.events.MessageEvent;
import tbn.comm.mina.TransportProtocol;
import tbn.comm.mina.NodeReference;

/**
 * Created by IntelliJ IDEA.
 * User: Sike Huang
 * Date: 2008-1-31
 * Time: 20:55:19
 * To change this template use File | Settings | File Templates.
 */
public class FloodMessage extends MessageEvent {
    private final String message;

    public FloodMessage(String message, NodeReference destination, NodeReference source, TransportProtocol protocol) {
        super(destination, source, protocol);
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
