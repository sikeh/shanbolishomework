package tbn.examples.hello;

import tbn.TBN;
import tbn.api.Channel;
import tbn.api.ChannelAlreadyExistsException;
import tbn.api.ChannelDoesNotExistException;
import tbn.api.ChannelHasNoSubscriptionsException;
import tbn.api.Component;
import tbn.api.ComponentAlreadyExistsException;
import tbn.api.ComponentCannotBeCreatedException;
import tbn.api.ComponentNotStartedException;
import tbn.api.Factory;
import tbn.api.FactoryCannotBeInstantiatedException;
import tbn.api.FactoryDoesNotExistException;
import tbn.api.HandlerAlreadySubscribedException;
import tbn.api.IllegalArgumentsForHandlerException;
import tbn.api.IllegalReconfigurationOperationException;
import tbn.api.MalformedComponentNameException;
import tbn.api.NoSuchMethodException;
import tbn.api.OutputEventAlreadyBoundToChannelException;
import tbn.api.TBNSystem;

public class HelloMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		TBNSystem sys = TBN.getSystem();

		try {
			sys.createComponentFactory("MyFactory",
					"tbn.examples.hello.MyComponent");
			sys.createComponentFactory("WorldFactory",
					"tbn.examples.hello.WorldComponent");
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		} catch (FactoryCannotBeInstantiatedException e2) {
			e2.printStackTrace();
		} catch (IllegalArgumentsForHandlerException e2) {
			e2.printStackTrace();
		}

		Factory myFactory = null;
		Factory worldFactory = null;
		try {
			myFactory = sys.findFactory("MyFactory");
			worldFactory = sys.findFactory("WorldFactory");
		} catch (FactoryDoesNotExistException e2) {
			e2.printStackTrace();
		}

		Component myComponent = null;
		Component worldComponent = null;
		try {
			myComponent = myFactory.create("Me");
			worldComponent = worldFactory.create("World");
		} catch (ComponentAlreadyExistsException e) {
			e.printStackTrace();
		} catch (ComponentCannotBeCreatedException e) {
			e.printStackTrace();
		} catch (MalformedComponentNameException e) {
			e.printStackTrace();
		}

		Channel helloChannel = null;
		Channel responseChannel = null;
		try {
			helloChannel = sys.createChannel("HelloChannel");
			helloChannel.addEventType(HelloEvent.class);
			responseChannel = sys.createChannel("ResponseChannel");
			responseChannel.addEventType(ResponseEvent.class);
		} catch (ChannelAlreadyExistsException e1) {
			e1.printStackTrace();
		}

		try {
			myComponent.subscribe("ResponseChannel", "handleResponseEvent");
			worldComponent.subscribe("HelloChannel", "handleHelloEvent");
		} catch (ChannelDoesNotExistException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalReconfigurationOperationException e) {
			e.printStackTrace();
		} catch (HandlerAlreadySubscribedException e) {
			e.printStackTrace();
		}

		try {
			myComponent.bindOutputEvent(HelloEvent.class, "HelloChannel");
			worldComponent.bindOutputEvent(ResponseEvent.class,
					"ResponseChannel");
		} catch (ChannelDoesNotExistException e) {
			e.printStackTrace();
		} catch (OutputEventAlreadyBoundToChannelException e) {
			e.printStackTrace();
		}

		myComponent.start();
		worldComponent.start();
		
		try {
			helloChannel.start();
			responseChannel.start();
		} catch (ChannelHasNoSubscriptionsException e) {
			e.printStackTrace();
		} catch (ComponentNotStartedException e) {
			e.printStackTrace();
		}

		sys.startReconfigurationServer();
	}
}
