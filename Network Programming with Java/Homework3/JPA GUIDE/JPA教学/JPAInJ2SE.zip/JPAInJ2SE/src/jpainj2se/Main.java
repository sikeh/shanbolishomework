/*
 * Main.java
 *
 * Created on 2007��4��22��, ����8:17
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jpainj2se;

import java.math.BigInteger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author BeanSoft
 */
public class Main {

    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAInJ2SEPU");
    
    /** Creates a new instance of Main */
    public Main() {
        Pavilion bean = new Pavilion();
        bean.setAddress("Beijing ����");
        bean.setId(new BigInteger("10"));
        bean.setPavilionname("����԰");
        persist(bean);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Main();
    }

    public void persist(Object object) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try {
            // TODO:
            em.persist(object);    em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
    }
    
}
