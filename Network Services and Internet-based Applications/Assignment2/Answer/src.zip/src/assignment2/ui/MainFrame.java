package assignment2.ui;


import assignment2.smtp.Email;
import assignment2.smtp.SmtpClient;
import assignment2.time.MailList;
import assignment2.time.SendMail;
import assignment2.util.SubjectDecoder;
import assignment2.util.UrlDecoder;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Calendar;


public class MainFrame
        extends JFrame {
    JPanel contentPane;
    BorderLayout borderLayout1 = new BorderLayout();
    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu jMenuFile = new JMenu();
    JMenuItem jMenuFileExit = new JMenuItem();
    JMenu jMenuHelp = new JMenu();
    JMenuItem jMenuHelpAbout = new JMenuItem();
    JScrollPane mainScrollPane = new JScrollPane();
    JTextArea infoTextArea = new JTextArea();
    JPanel showInfoPanel = new JPanel();
    JPanel setupPanel = new JPanel();
    JLabel ipAddressLabelText = new JLabel();
    JLabel separateLabel1 = new JLabel();
    JLabel totalLabelText = new JLabel();
    JLabel totalLabel = new JLabel();
    JLabel separateLabel2 = new JLabel();
    JLabel availableLabelText = new JLabel();
    JLabel availableLabel = new JLabel();
    JLabel availableLabelM = new JLabel();
    JLabel portLabelText = new JLabel();
    JButton startButton = new JButton();
    JButton stopButton = new JButton();
    JMenuItem guideMenuItem = new JMenuItem();
    JTextField portTextField = new JTextField();

    assignment2.ui.MemoryProperty availableMemory = new assignment2.ui.MemoryProperty();

    String indexFile = "index.html";
    String indexDirectories = "./";
    int flux = 0;
    int i = 1;

    private SendMail sendMail = SendMail.getInstance();
    private MailList mailist = MailList.getInstance();
    private SmtpClient smtpClient = SmtpClient.getInstance();


    public MainFrame() {
        smtpClient.addObserver(mailist);
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        }
        catch (Exception exception) {
           // exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setSize(new Dimension(800, 600));
        setTitle("Web Server by Biiblesoft");
        jMenuFile.setText("File");
        jMenuFileExit.setText("Exit");
        jMenuFileExit.addActionListener(new MainFrame_jMenuFileExit_ActionAdapter(this));
        jMenuHelp.setText("Help");
        jMenuHelpAbout.setText("About");
        infoTextArea.setEditable(false);
        infoTextArea.setText("Welcome to use Biiblesoft Web Server\n");
        infoTextArea.setForeground(Color.BLUE);
        ipAddressLabelText.setText("Host IP:");
        separateLabel1.setForeground(Color.green);
        separateLabel1.setText("|");
        totalLabelText.setText("Connect Count:");
        totalLabel.setMaximumSize(new Dimension(18, 15));
        totalLabel.setMinimumSize(new Dimension(18, 15));
        totalLabel.setPreferredSize(new Dimension(18, 15));
        totalLabel.setToolTipText("");
        totalLabel.setText("0");
        separateLabel2.setForeground(Color.green);
        separateLabel2.setText("|");
        availableLabelText.setText("JVM Available Memory:");
        availableLabel.setText("" + availableMemory.getAvailableMemory() / 1024);
        availableLabelM.setText("M");
        portLabelText.setText("Port:");
        startButton.setText("Start");
        startButton.addActionListener(new MainFrame_startButton_actionAdapter(this));
        stopButton.setText("Stop");
        stopButton.addActionListener(new MainFrame_stopButton_actionAdapter(this));
        guideMenuItem.setText("Help");
        guideMenuItem.addActionListener(new MainFrame_guideMenuItem_actionAdapter(this));
        portTextField.setPreferredSize(new Dimension(51, 20));
        portTextField.setText("8080");
        portTextField.setHorizontalAlignment(SwingConstants.RIGHT);
        portTextField.addCaretListener(new MainFrame_portTextField_caretAdapter(this));
        setupMenu.setText("Setup");
        mainFloderMenuItem.setText("Root Directory");
        mainFloderMenuItem.addActionListener(new
                MainFrame_mainFloderMenuItem_actionAdapter(this));
        jMenuItem2.setText("Defult index file");
        jMenuItem2.addActionListener(new MainFrame_jMenuItem2_actionAdapter(this));
        showIPLabel.setText(new IP().getLocalHostIP());
        jLabel1.setForeground(Color.green);
        jLabel1.setText("|");
        flowTextLabel.setText("Flow:");
        flowLabel.setText("0");
        jLabel3.setText("K");
        jMenuBar1.add(jMenuFile);
        jMenuBar1.add(setupMenu);
        jMenuFile.add(jMenuFileExit);
        jMenuBar1.add(jMenuHelp);
        jMenuHelp.add(guideMenuItem);
        contentPane.add(mainScrollPane, java.awt.BorderLayout.CENTER);
        mainScrollPane.getViewport().add(infoTextArea);
        contentPane.add(showInfoPanel, java.awt.BorderLayout.SOUTH);
        showInfoPanel.add(ipAddressLabelText);
        showInfoPanel.add(showIPLabel);
        showInfoPanel.add(separateLabel1);
        showInfoPanel.add(totalLabelText);
        showInfoPanel.add(totalLabel);
        showInfoPanel.add(jLabel1);
        showInfoPanel.add(flowTextLabel);
        showInfoPanel.add(flowLabel);
        showInfoPanel.add(jLabel3);
        contentPane.add(setupPanel, java.awt.BorderLayout.NORTH);
        setupPanel.add(portLabelText);
        setupPanel.add(portTextField);
        setupPanel.add(startButton);
        setupPanel.add(stopButton);
        setupMenu.add(mainFloderMenuItem);
        setupMenu.add(jMenuItem2);
        setJMenuBar(jMenuBar1);

    }

    /**
     * Check if it is a number
     *
     * @param s String
     * @return boolean
     */
    public boolean isNumber(String s) {
        try {
            Integer.parseInt(s);
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }

    /**
     * error message for worng format at port number
     */

    public void showWarningMessage() {
        String title = "Invalid input";
        String message = "             number here only";
        int type = javax.swing.JOptionPane.WARNING_MESSAGE;
        JDialog Warningdialog1 = new JDialog();
        javax.swing.JOptionPane.showMessageDialog(Warningdialog1, message, title,
                type);
    }

    /**
     * File | Exit action performed.
     *
     * @param actionEvent ActionEvent
     */
    void jMenuFileExit_actionPerformed(ActionEvent actionEvent) {
        System.exit(0);
    }


    void guideMenuItem_actionPerformed(ActionEvent e) {
        String title = "How to use it";
        String message = "Setup the port number and click start\n";

        int type = JOptionPane.INFORMATION_MESSAGE;
        JDialog dialog = new JDialog();
        javax.swing.JOptionPane.showMessageDialog(dialog, message, title,
                type);
    }

    public void portTextField_caretUpdate(CaretEvent e) {
        String checkText = portTextField.getText();
        if (!isNumber(checkText) && !checkText.equals("")) {
            showWarningMessage();
        }

    }


    class ConnectionThread
            extends Thread {
        Socket client;
        int counter;

        public ConnectionThread(Socket cl, int c) {
            client = cl;
            counter = c;
        }

        public void run() {
            try {
                String destIP = client.getInetAddress().toString(); // client ip
                int destport = client.getPort(); // client port
                // Time time = new Time();
                DayAndTime d = new DayAndTime();
                infoTextArea.append("connect with " + destIP + ":" + destport + " at " + d.getTime() + ".\n");
                totalLabel.setText("" + counter);
                PrintStream outstream = new PrintStream(client.getOutputStream());
                BufferedReader instream = new BufferedReader(new InputStreamReader(
                        client.getInputStream()));
                String inline = instream.readLine(); // read request
                infoTextArea.append("receive:" + inline + "\n");
                if (isGet(inline)) { // if it is a get request
                    String filename = indexDirectories + getfilename(inline);
                    if (filename.equals(indexDirectories + indexFile)) {
                        filename = indexFile;
                        returnFile(outstream, filename);
                    } else if (inline.startsWith("GET /?send=Back")) {
                        filename = indexFile;
                        returnFile(outstream, filename);
                    } else if (inline.toLowerCase().startsWith("get /status")) {
                        returnStatus(outstream);
                    }

                } else if (isPost(inline)) {

                    while (true) {
                        inline = instream.readLine();
                        if (inline.startsWith("from=")) {
//                            System.out.println(inline);
                            break;
                        }
                    }

                    String[] args = inline.split("&");
                    String from = SubjectDecoder.decode(args[0].substring(5));
                    if (!isValidEmailFormat(from)) {
                        returnHTML(false, "FROM is not a valid email address", outstream);
                        client.close();
                        return;
                    }
                    String to = SubjectDecoder.decode(args[1].substring(3));
                    if (!isValidEmailFormat(to)) {
                        returnHTML(false, "TO is not a valid email address", outstream);
                        client.close();
                        return;
                    }
                    String smtp = SubjectDecoder.decode(args[2].substring(5));
                    String subjectFromURL = args[3].substring(8);
                    String message = UrlDecoder.decode(args[4].substring(8));


                    int year = 0;
                    int month = 0;
                    int day = 0;
                    int hour = 0;
                    int minute = 0;


                    try {
                        year = Integer.valueOf(args[5].substring(5));
                        month = Integer.valueOf(args[6].substring(6));
                        day = Integer.valueOf(args[7].substring(4));
                        hour = Integer.valueOf(args[8].substring(5));
                        minute = Integer.valueOf(args[9].substring(7));

                        if (year < 2008 || month < 0 || month > 12 || day < 0 || day > 31 || hour < 0 || hour > 60 || minute < 0 || minute > 60) {
                            returnAndClose(outstream);
                            return;
                        }


                    } catch (NumberFormatException e) {
                        returnAndClose(outstream);
                        return;
                    }

                    Calendar calendar = Calendar.getInstance();
                    calendar.clear();
                    calendar.set(year, month - 1, day, hour, minute);
                    if (smtp.equals("")) {
                        sendMail.schedule(new Email(from, to, subjectFromURL, message, calendar));
                    } else {
                        sendMail.schedule(new Email(from, to, smtp, subjectFromURL, message, calendar));
                    }


                    returnHTML(true, "Done", outstream);
                }
                client.close();
            }
            catch (IOException e3) {
                infoTextArea.append("\n");
            } catch (Exception e) {
               // e.printStackTrace();
            }

        }

        private void returnAndClose(PrintStream outstream) throws IOException {
            returnHTML(false, "Invalid Date Format", outstream);
            client.close();
            return;
        }

        public boolean isValidEmailFormat(String emailAddress) {
            //Match the given string with the pattern
            boolean isValid = emailAddress.matches(".+@.+\\.[a-z]+");

            if (isValid) {
                return true;
            } else {
                return false;
            }
        }


        /**
         * Return a file, if file not exist return 404 no find
         *
         * @param outstream
         * @param filename
         */
        private void returnFile(PrintStream outstream, String filename) {
            File file = new File(filename);
            if (file.exists()) { // if file exists, send it
                infoTextArea.append("request for " + filename + "\n");
                infoTextArea.append(
                        "_________________________________________________\n\n");
                outstream.println("HTTP/1.0 200 OK");
                outstream.println("MIME_version:1.0");
                outstream.println("Content_Type:text/html");
                int len = (int) file.length();
                flux += len / 1024;
                flowLabel.setText("" + flux);
                outstream.println("Content_Length:" + len);
                outstream.println("");
                sendfile(outstream, file);      //send file
                outstream.flush();
            } else { // file not available
                String notfound = "<html><head><title>Not Found</title><META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\"></head><body><h1>Error 404-file not found</h1></body></html>";
                outstream.println("HTTP/1.0 404 no found");
                outstream.println("Content_Type:text/html");
                outstream.println("Content_Length:" + notfound.length() + 2);
                outstream.println("");
                outstream.println(notfound);
                outstream.flush();
                infoTextArea.append("request file:" + file + "does not exist\n");
                infoTextArea.append(
                        "_________________________________________________\n\n");
            }
        }

        /**
         * return the result
         *
         * @param isSuccessful
         * @param message
         * @param outStream
         */
        private void returnHTML(boolean isSuccessful, String message, PrintStream outStream) {
            StringBuilder sb = new StringBuilder();
            sb.append("<html><head><title>iMail by Biiblesoft</title><META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\"></head><body><h1>");
            if (isSuccessful) {
                sb.append("Email schedules Successful");
            } else {
                sb.append("Faild");
            }
            sb.append("</h1><p>");
            sb.append(message);
            sb.append("</p>");
            sb.append("<form>\n" +
                    "<input type=\"button\" value=\"Back\" onclick=\"history.back();\">\n" +
                    "</form>");

            outStream.println("HTTP/1.0 200 OK");
            outStream.println("MIME_version:1.0");
            outStream.println("Content_Type:text/html");
            outStream.println("Content_Length:" + sb.length());
            outStream.println("");
            outStream.println(sb.toString());
            outStream.flush();
        }

        private void returnStatus(PrintStream outStream) {
            StringBuilder sb = new StringBuilder();
            sb.append("<html><head><title>iMail by Biiblesoft</title></head><body><h1>");
            sb.append("Email List");
            sb.append("</h1><p>");
            sb.append(mailist.toHTML());
            sb.append("</p>");
            sb.append("<form>\n" +
                    "<input type=\"button\" value=\"Back\" onclick=\"history.back();\">\n" +
                    "</form>");

            outStream.println("HTTP/1.0 200 OK");
            outStream.println("MIME_version:1.0");
            outStream.println("Content_Type:text/html");
            outStream.println("Content_Length:" + sb.length());
            outStream.println("");
            outStream.println(sb.toString());
            outStream.flush();
        }


        /**
         * if it is a GET
         *
         * @param s String
         * @return boolean
         */
        boolean isGet(String s) {
            if (s.length() > 0) {
                if (s.substring(0, 3).equalsIgnoreCase("GET")) {
                    return true;
                }
            }
            return false;
        }

        boolean isPost(String s) {
            if (s.length() > 0) {
                if (s.substring(0, 4).equalsIgnoreCase("POST")) {
                    return true;
                }
            }
            return false;
        }

        /**
         * get request file name
         *
         * @param s String
         * @return String
         */
        String getfilename(String s) {
            String f = s.substring(s.indexOf(' ') + 1);
            f = f.substring(0, f.indexOf(' '));
            try {
                if (f.charAt(0) == '/') {
                    f = f.substring(1);
                }
            }
            catch (StringIndexOutOfBoundsException e) {
                //infoTextArea.append("Error:" + e + "\n");
            }
            if (f.equals("")) {
                f = indexFile;
            }
            return f;
        }

        /**
         * send request to Web Browser
         *
         * @param outs PrintStream
         * @param file File
         */
        void sendfile(PrintStream outs, File file) {
            try {
                DataInputStream in = new DataInputStream(new FileInputStream(file));
                int len = (int) file.length();
                byte buf[] = new byte[len];
                in.readFully(buf);
                outs.write(buf, 0, len);
                outs.flush();
                in.close();
            }
            catch (Exception e) {
                infoTextArea.append("Error while send file!\n");
                //System.exit(1);
            }
        }
    }


    class StartServe
            extends Thread {
        ServerSocket server = null;
        Socket client = null;
        int servePort = 8080;

        public StartServe(int p) {
            servePort = p;
        }

        public void close() {
            try {
                client.close();
                server.close();
            }
            catch (Exception eee) {
                infoTextArea.append("\n");
            }
        }

        public void run() {
            try {
                server = new ServerSocket(servePort);
                infoTextArea.append("\nListening request at " + servePort +
                        "\n**************************************************\n\n");
                for (; ;) {
                    client = server.accept(); // accept request
                    new ConnectionThread(client, i).start();
                    i++;
                }
            }
            catch (Exception e1) {
                infoTextArea.append("\n");
            }

        }
    }

    StartServe startServe = null;
    JMenu setupMenu = new JMenu();
    JMenuItem mainFloderMenuItem = new JMenuItem();
    JMenuItem jMenuItem2 = new JMenuItem();
    JLabel showIPLabel = new JLabel();
    JLabel jLabel1 = new JLabel();
    JLabel flowTextLabel = new JLabel();
    JLabel flowLabel = new JLabel();
    JLabel jLabel3 = new JLabel();

    public void startButton_actionPerformed(ActionEvent e) {

        int port = Integer.parseInt(portTextField.getText());
        startServe = new StartServe(port);
        startServe.start();

    }

    public void stopButton_actionPerformed(ActionEvent e) {
        try {
            startServe.close();
        }
        catch (Exception eeee) {

        }
        infoTextArea.append("stop\n" +
                "**************************************************\n\n");
    }

    public void jMenuItem2_actionPerformed(ActionEvent e) {

        JFrame f = new JFrame("Choose file");
        f.setSize(400, 300);
        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = f.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        f.setLocation((screenSize.width - frameSize.width) / 2,
                (screenSize.height - frameSize.height) / 2);

        f.setVisible(true);
        JFileChooser fileChooser = new JFileChooser(indexDirectories);
        fileChooser.setApproveButtonText("OK");
        File file = null;
        int result;
        result = fileChooser.showOpenDialog(f);
        f.dispose();
        if (result == JFileChooser.OPEN_DIALOG) {
            file = fileChooser.getSelectedFile();
            indexFile = file.getAbsolutePath();

            infoTextArea.append("\ndefult file: " + indexFile + "\n");

        }

    }

    public void mainFloderMenuItem_actionPerformed(ActionEvent e) {
        JFrame f = new JFrame("Choose File");
        f.setSize(400, 300);
        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = f.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        f.setLocation((screenSize.width - frameSize.width) / 2,
                (screenSize.height - frameSize.height) / 2);

        f.setVisible(true);
        JFileChooser fileChooser = new JFileChooser(".");
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fileChooser.setApproveButtonText("OK");
        File file = null;
        int result;
        result = fileChooser.showOpenDialog(f);
        f.dispose();
        if (result == JFileChooser.OPEN_DIALOG) {
            file = fileChooser.getSelectedFile();
            indexDirectories = file.getAbsolutePath();
            // infoTextArea.setForeground(Color.BLUE);
            infoTextArea.append("\ndefult root directory:" + indexDirectories + "\n");
            //infoTextArea.setForeground(Color.black);
        }


    }

}

class MainFrame_mainFloderMenuItem_actionAdapter
        implements ActionListener {
    private MainFrame adaptee;

    MainFrame_mainFloderMenuItem_actionAdapter(MainFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.mainFloderMenuItem_actionPerformed(e);
    }
}

class MainFrame_jMenuItem2_actionAdapter
        implements ActionListener {
    private MainFrame adaptee;

    MainFrame_jMenuItem2_actionAdapter(MainFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem2_actionPerformed(e);
    }
}

class MainFrame_stopButton_actionAdapter
        implements ActionListener {
    private MainFrame adaptee;

    MainFrame_stopButton_actionAdapter(MainFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.stopButton_actionPerformed(e);
    }
}

class MainFrame_startButton_actionAdapter
        implements ActionListener {
    private MainFrame adaptee;

    MainFrame_startButton_actionAdapter(MainFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.startButton_actionPerformed(e);
    }
}

class MainFrame_portTextField_caretAdapter
        implements CaretListener {
    private MainFrame adaptee;

    MainFrame_portTextField_caretAdapter(MainFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void caretUpdate(CaretEvent e) {
        adaptee.portTextField_caretUpdate(e);
    }
}

class MainFrame_guideMenuItem_actionAdapter
        implements ActionListener {
    private MainFrame adaptee;

    MainFrame_guideMenuItem_actionAdapter(MainFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.guideMenuItem_actionPerformed(e);
    }
}

class MainFrame_jMenuFileExit_ActionAdapter
        implements ActionListener {
    MainFrame adaptee;

    MainFrame_jMenuFileExit_ActionAdapter(MainFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.jMenuFileExit_actionPerformed(actionEvent);
    }
}





