package assignment2.ui;


public class MemoryProperty {

  private Runtime rt = Runtime.getRuntime();

  public long getAvailableMemory() {

    return rt.freeMemory();
  }
}
