package assignment2.smtp;



import assignment2.util.UrlDecoder;
import assignment2.util.SubjectDecoder;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: Shanbo
 * Date: Mar 30, 2008
 * Time: 10:40:07 PM
 */
public class Email implements Comparable<Email> {
    protected long serial;
    private String from;
    private String to;
    private String smtp;
    private String subject;
    private String message;
    private Calendar calendar;
    private MailState mailState;
    private String resultMessage;
    private Date submitDate;


    public Email() {
    }

    public Email(String from, String to, String subject, String message) {
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.message = message;
    }

    public Email(String from, String to, String smtp, String subject, String message, Calendar calendar) {
        this(from, to, subject, message, calendar);
        this.smtp = smtp;
    }

    public Email(String from, String to, String subject, String message, Calendar calendar) {
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.message = message;
        this.calendar = calendar;
        this.mailState = MailState.PENDING;
        this.smtp = "";
        this.resultMessage = "";
        this.serial = System.currentTimeMillis();
        this.submitDate = new Date(System.currentTimeMillis());
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getSmtp() {
        return smtp;
    }

    public void setSmtp(String smtp) {
        this.smtp = smtp;
    }

    public String getSMTPSubject() {
        return UrlDecoder.decode(subject);
    }

    public String getShowSubject(){
        return SubjectDecoder.decode(subject);
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Calendar getCalendar() {
        return calendar;
    }

    public void setCalendar(Calendar calendar) {
        this.calendar = calendar;
    }

    public MailState getMailStatus() {
        return mailState;
    }

    public void setMailState(MailState mailState) {
        this.mailState = mailState;
    }


    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Email email = (Email) o;

        if (serial != email.serial) return false;
        if (calendar != null ? !calendar.equals(email.calendar) : email.calendar != null) return false;
        if (from != null ? !from.equals(email.from) : email.from != null) return false;
        if (mailState != email.mailState) return false;
        if (message != null ? !message.equals(email.message) : email.message != null) return false;
        if (resultMessage != null ? !resultMessage.equals(email.resultMessage) : email.resultMessage != null)
            return false;
        if (smtp != null ? !smtp.equals(email.smtp) : email.smtp != null) return false;
        if (subject != null ? !subject.equals(email.subject) : email.subject != null) return false;
        if (to != null ? !to.equals(email.to) : email.to != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (int) (serial ^ (serial >>> 32));
        result = 31 * result + (from != null ? from.hashCode() : 0);
        result = 31 * result + (to != null ? to.hashCode() : 0);
        result = 31 * result + (smtp != null ? smtp.hashCode() : 0);
        result = 31 * result + (subject != null ? subject.hashCode() : 0);
        result = 31 * result + (message != null ? message.hashCode() : 0);
        result = 31 * result + (calendar != null ? calendar.hashCode() : 0);
        result = 31 * result + (mailState != null ? mailState.hashCode() : 0);
        result = 31 * result + (resultMessage != null ? resultMessage.hashCode() : 0);
        return result;
    }

    public int compareTo(Email that) {
        if (this.serial > that.serial)
            return 1;
        else if (this.serial < that.serial)
            return -1;
        else
            return 0;
    }
}
