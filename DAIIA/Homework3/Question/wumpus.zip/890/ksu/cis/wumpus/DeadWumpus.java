package ksu.cis.wumpus;

/**
 * This type was created in VisualAge.
 */
public class DeadWumpus extends Thing{
}
