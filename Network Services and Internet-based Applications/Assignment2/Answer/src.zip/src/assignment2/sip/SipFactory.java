package assignment2.sip;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * User: Shanbo Li
 * Date: Apr 13, 2008
 * Time: 3:24:09 PM
 *
 * @author Shanbo Li
 */
public class SipFactory {
    public static final Logger logger = Logger.getLogger(SipFactory.class.getName());

    public static String getResponse(String[] lines, int rtpPort) throws ConstructSdpFailedException, ConstructSipFailedException {
        String sip;
        SIPBean sipBean = new SIPBean();
        SDPBean sdpBean = new SDPBean();
        int fromTag = -1;
        String toTag = null;
        for (String line : lines) {
            if (line.startsWith("Via:")) {
                sipBean.setVia(line + "\r\n");
            }

            if (line.startsWith("Record-Route:")) {
                sipBean.setRoute(line + "\r\n");
            }

            if (line.startsWith("To:")) {
                if (toTag != null) {
                    sipBean.setRoute(line + ";tag=" + toTag + "\r\n");
                } else {
                    sipBean.setRoute(line + "\r\n");
                }

                sipBean.setContact("Contact: " + line.substring(4) + "\r\n");
            }

            if (line.startsWith("From:")) {
                sipBean.setFrom(line + "\r\n");
                try {
                    fromTag = Integer.parseInt(line.substring(line.length() - 4));
                } catch (NumberFormatException e) {
                }
                if (fromTag != -1) {
                    toTag = GenerateTag.getTag(fromTag);
                }
            }

            if (line.startsWith("Call-ID:")) {
                sipBean.setCallId(line + "\r\n");
            }

            if (line.startsWith("CSeq:")) {
                sipBean.setCseq(line + "\r\n");
            }

            if (line.startsWith("s=")) {
                sdpBean.setS(line + "\r\n");
            }


        }

        sdpBean.setMWithPort(String.valueOf(rtpPort));

        try {
            sipBean.setSdp(sdpBean.getSdp());
        } catch (ConstructSdpFailedException e) {
            logger.log(Level.SEVERE, null, e);
            throw e;
        }

        try {
            sip = sipBean.getSip();
        } catch (ConstructSipFailedException e) {
            logger.log(Level.SEVERE, null, e);
            throw e;
        }

        return sip;
    }

}
