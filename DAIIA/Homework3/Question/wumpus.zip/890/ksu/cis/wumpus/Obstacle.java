package ksu.cis.wumpus;

public interface Obstacle {}
