package ksu.cis.wumpus;

/**
 * This type was created in VisualAge.
 */
public class Hope {
/**
 * Hope constructor comment.
 */
public Hope() {
	super();
}
}
