package assignment2;

/**
 * Created by IntelliJ IDEA.
 * User: Sike Huang
 * Date: 2008-4-19
 * Time: 22:35:19
 * To change this template use File | Settings | File Templates.
 */
public class SipSpeaker {

    private String defaultMessage = "default.wav";
    private String messageWav = "currentmessage.wav";
    private String messageText = "Welcome to the SIP Speaker this is my own answering machine. You have no new message.";
    private long messageReceived = 43534522135L;
    private String sipInterface = "0.0.0.0";
    private int sipPort = 5060;
    private String sipUser = "robot";
    private String httpInterface = "127.0.0.1";

    public static void main(String[] args) {
        if (args.length != 6) {
            System.out.println("java assignment2.SipSpeaker [-c config_file_name] [-user sip_uri] [-http http_bind_address]");
            System.exit(0);
        }
        if (!args[0].equals("-c") || !args[2].equals("-user") || !args[4].equals("-http")) {
            
        }
    }
}
