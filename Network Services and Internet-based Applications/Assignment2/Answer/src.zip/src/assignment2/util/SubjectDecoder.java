package assignment2.util;

/**
 * Created by IntelliJ IDEA.
 * User: Sike Huang
 * Date: 2008-4-1
 * Time: 15:38:49
 * To change this template use File | Settings | File Templates.
 */
public class SubjectDecoder {

    public static String decode(String in) {
        in = in.replaceAll("\\+", " ");
        in = in.replaceAll("%21", "!");
        in = in.replaceAll("%23", "#");
        in = in.replaceAll("%24", "\\$");
        in = in.replaceAll("%25", "%");
        in = in.replaceAll("%5E", "^");
        in = in.replaceAll("%26", "&");
        in = in.replaceAll("%27", "'");
        in = in.replaceAll("%28", "(");
        in = in.replaceAll("%29", ")");
        in = in.replaceAll("%2B", "+");
        in = in.replaceAll("%3B", ";");
        in = in.replaceAll("%3A", ":");
        in = in.replaceAll("%2A", "*");
        in = in.replaceAll("%2F", "/");
        in = in.replaceAll("%3C", "<");
        in = in.replaceAll("%3D", "=");
        in = in.replaceAll("%3E", ">");
        in = in.replaceAll("%3F", "?");
        in = in.replaceAll("%5B", "[");
        in = in.replaceAll("%5C", "\\\\");      // are you kidding me?
        in = in.replaceAll("%5D", "]");
        in = in.replaceAll("%5E", "^");
        in = in.replaceAll("%5F", "_");
        in = in.replaceAll("%60", "`");
        in = in.replaceAll("%7B", "{");
        in = in.replaceAll("%7C", "|");
        in = in.replaceAll("%7D", "}");
        in = in.replaceAll("%7E", "~");
        in = in.replaceAll("%22", "\"");
        in = in.replaceAll("%2C", ",");
//        in = in.replaceAll("%0D%0A", "\r\n");
        /**
         * Lines consist of zero or more data
         * characters terminated by the sequence ASCII character "CR" (hex value
         * 0D) followed immediately by ASCII character "LF" (hex value 0A).
         */
        in = in.replaceAll("%0D%0A", "=0D=0A");

        //ISO-8859-15 Characters in Hex 
        in = in.replaceAll("%A2", "�");
        in = in.replaceAll("%A3", "�");
        in = in.replaceAll("%A4", "�");
        in = in.replaceAll("%A5", "�");
        in = in.replaceAll("%B0", "�");
        in = in.replaceAll("%BC", "�");
        in = in.replaceAll("%BC", "�");
        in = in.replaceAll("%BD", "�");
        in = in.replaceAll("%BD", "�");
        in = in.replaceAll("%BE", "�");
        in = in.replaceAll("%BE", "�");
        in = in.replaceAll("%A1", "�");
        in = in.replaceAll("%AB", "�");
        in = in.replaceAll("%BB", "�");
        in = in.replaceAll("%BF", "�");
        in = in.replaceAll("%C0", "�");
        in = in.replaceAll("%C1", "�");
        in = in.replaceAll("%C2", "�");
        in = in.replaceAll("%C3", "�");
        in = in.replaceAll("%C4", "�");
        in = in.replaceAll("%C5", "�");
        in = in.replaceAll("%C6", "�");
        in = in.replaceAll("%C7", "�");
        in = in.replaceAll("%C8", "�");
        in = in.replaceAll("%C9", "�");
        in = in.replaceAll("%CA", "�");
        in = in.replaceAll("%CB", "�");
        in = in.replaceAll("%CC", "�");
        in = in.replaceAll("%CD", "�");
        in = in.replaceAll("%CE", "�");
        in = in.replaceAll("%CF", "�");
        in = in.replaceAll("%D0", "�");
        in = in.replaceAll("%D1", "�");
        in = in.replaceAll("%D2", "�");
        in = in.replaceAll("%D3", "�");
        in = in.replaceAll("%D4", "�");
        in = in.replaceAll("%D5", "�");
        in = in.replaceAll("%D6", "�");
        in = in.replaceAll("%D8", "�");
        in = in.replaceAll("%D9", "�");
        in = in.replaceAll("%DA", "�");
        in = in.replaceAll("%DB", "�");
        in = in.replaceAll("%DC", "�");
        in = in.replaceAll("%DD", "�");
        in = in.replaceAll("%DE", "�");
        in = in.replaceAll("%DF", "�");
        in = in.replaceAll("%E0", "�");
        in = in.replaceAll("%E1", "�");
        in = in.replaceAll("%E2", "�");
        in = in.replaceAll("%E3", "�");
        in = in.replaceAll("%E4", "�");
        in = in.replaceAll("%E5", "�");
        in = in.replaceAll("%E6", "�");
        in = in.replaceAll("%E7", "�");
        in = in.replaceAll("%E8", "�");
        in = in.replaceAll("%E9", "�");
        in = in.replaceAll("%EA", "�");
        in = in.replaceAll("%EB", "�");
        in = in.replaceAll("%EC", "�");
        in = in.replaceAll("%ED", "�");
        in = in.replaceAll("%EE", "�");
        in = in.replaceAll("%EF", "�");
        in = in.replaceAll("%F0", "�");
        in = in.replaceAll("%F1", "�");
        in = in.replaceAll("%F2", "�");
        in = in.replaceAll("%F3", "�");
        in = in.replaceAll("%F4", "�");
        in = in.replaceAll("%F5", "�");
        in = in.replaceAll("%F6", "�");
        in = in.replaceAll("%F8", "�");
        in = in.replaceAll("%F9", "�");
        in = in.replaceAll("%FA", "�");
        in = in.replaceAll("%FB", "�");
        in = in.replaceAll("%FC", "�");
        in = in.replaceAll("%FD", "�");
        in = in.replaceAll("%FE", "�");
        in = in.replaceAll("%FF", "�");

        return in;
    }
}
