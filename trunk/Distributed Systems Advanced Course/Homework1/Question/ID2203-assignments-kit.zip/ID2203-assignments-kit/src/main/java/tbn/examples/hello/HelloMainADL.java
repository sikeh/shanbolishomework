package tbn.examples.hello;

import tbn.TBN;
import tbn.api.ParsingFailedException;
import tbn.api.SystemBuildFailedException;
import tbn.api.TBNSystem;

public class HelloMainADL {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		TBNSystem sys = TBN.getSystem();
		try {
			sys.buildSystem(HelloMainADL.class.getResource("hello.xml").getPath());
			sys.startReconfigurationServer();
		} catch (ParsingFailedException e) {
			e.printStackTrace();
		} catch (SystemBuildFailedException e) {
			e.printStackTrace();
		}
	}
}
