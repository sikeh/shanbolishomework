package assignment1.events;

import tbn.api.Event;

/**
 * Created by IntelliJ IDEA.
 * User: Sike Huang
 * Date: 2008-1-30
 * Time: 21:38:12
 * To change this template use File | Settings | File Templates.
 */
public class FloodDoneEvent implements Event {
    private final String message;

    public FloodDoneEvent(String message) {
        this.message = message;
    }   

    public String getMessage() {
        return "Flooding is DONE...";
    }
}
