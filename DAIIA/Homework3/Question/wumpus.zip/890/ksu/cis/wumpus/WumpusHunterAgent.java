package ksu.cis.wumpus;

/* fill in the methods of this class ... you may add or delete any methods
   algorithms, or data structures you need. */
   
import java.io.*;
class WumpusHunterAgent implements AgentProgram {
	// constants
	private final int right= 0;
	private final int left = 1;
	private final int up   = 2;
	private final int down = 3;

	// hidden attributes.  xLoc and yLoc are for the agent to "know" where it is
	private int xSize, ySize, xLoc, yLoc;
	private int gridMemory[][][];

	public WumpusHunterAgent(int xSize, int ySize) {
		this.xSize = xSize;
		this.ySize = ySize;
		xLoc = xSize;
		yLoc = ySize;
	}
//Main Method
	public Action execute(Percept perceptArg) 
	{
		WumpusPercept percept = (WumpusPercept) perceptArg;


		if (percept.isGlitter) 
			return new AnAction("grab");
			
		if (percept.isBump)
			return new AnAction("turn", AIMA.randomChoice("right", "left"));

		if (percept.isBreeze)
			if (AIMA.random() < .60)
				return new AnAction("turn", AIMA.randomChoice("right", "left"));
				
		if (percept.isStench)
			if (AIMA.random() < .08)
				return new AnAction("shoot");
			else 
				if (AIMA.random() < .3)
					return new AnAction("forward");
				else
					return new AnAction("turn", AIMA.randomChoice("right", "left"));

		if (AIMA.random() < .8)
			return new AnAction("forward");
		else
			return new AnAction("turn", AIMA.randomChoice("right", "left"));

	}
}
