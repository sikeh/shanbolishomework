package assignment2.util;

/**
 * Created by IntelliJ IDEA.
 * User: Sike Huang
 * Date: 2008-4-1
 * Time: 15:38:49
 * To change this template use File | Settings | File Templates.
 */
public class UrlDecoder {

    public static String decode(String in) {
        in = in.replaceAll("\\+", "=20");
        in = in.replaceAll("%", "=");
        return in;
    }
}
