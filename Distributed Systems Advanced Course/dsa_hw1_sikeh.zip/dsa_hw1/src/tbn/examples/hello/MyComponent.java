package tbn.examples.hello;

import tbn.api.Component;

public class MyComponent {

    private final Component component;
	
	public MyComponent(Component component) {
		this.component = component;
	}
	
	public void start() {
		component.raiseEvent(new HelloEvent("Hello")); 
		
		System.out.println("Me: I said Hello to the World");
	}
	
	public void handleResponseEvent(ResponseEvent event) {
		String message = event.getMessage();
		
		System.out.println("Me: I got message: \"" + message + "\"");
	}
}
