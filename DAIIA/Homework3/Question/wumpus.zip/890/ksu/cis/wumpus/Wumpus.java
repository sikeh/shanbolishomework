package ksu.cis.wumpus;

/**
 * This type is the nasty smelly dude that eats you
 */
public class Wumpus extends Thing implements Terminator{
}
