package tbn.examples.hello;

import tbn.api.Event;

public class HelloEvent implements Event {
	private final String message;

	public HelloEvent(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
