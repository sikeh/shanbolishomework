package ksu.cis.wumpus;

public interface UnaryPredicate {
	public boolean execute (Object x);
}
