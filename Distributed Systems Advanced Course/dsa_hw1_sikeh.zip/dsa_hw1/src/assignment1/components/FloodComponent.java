package assignment1.components;

import tbn.api.Component;
import tbn.comm.mina.NodeReference;
import tbn.comm.mina.TransportProtocol;
import tbn.comm.mina.MessageHandler;
import tbn.comm.mina.events.MessageEvent;
import assignments.util.TopologyDescriptor;
import assignment1.events.InitEvent;
import assignment1.events.FloodInitEvent;
import assignment1.events.FloodMessage;
import assignment1.events.FloodDoneEvent;

import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: Sike Huang
 * Date: 2008-1-31
 * Time: 20:14:34
 * To change this template use File | Settings | File Templates.
 */
public class FloodComponent {
    private Component component;
    private TopologyDescriptor topologyDescriptor;
    private MessageHandler messageHandler;
//    private HashMap<String, HashMap<NodeReference, Boolean>> msgHashMap;
//    private

    public FloodComponent(Component component) {
        this.component = component;
    }

    /**
     * It handles the InitEvent triggered by the application
     * component and stores the topology descriptor (specifying all the process'
     * neighbors) in an internal variable.
     *
     * @param event
     */
    public void handleInitEvent(InitEvent event) {
        topologyDescriptor = event.getTopologyDescriptor();
        messageHandler = new MessageHandler(this.component);
//        topologyDescriptor.get
    }

    /**
     * Upon receiving a FloodInitEvent, the flood
     * component sends a FloodMessage to all its neighbors.
     *
     * @param event
     */
    public void handleFloodInitEvent(FloodInitEvent event) {
        NodeReference myNodeRef = topologyDescriptor.getMyNodeRef();
        for (NodeReference otherNodeRef : topologyDescriptor.getAllOtherNodes()) {
            // TODO MessageEvent or FloodMessage ?
            MessageEvent floodMsg = new FloodMessage(event.getMessage(), otherNodeRef, myNodeRef, TransportProtocol.TCP);
            messageHandler.send(floodMsg, otherNodeRef);
        }
    }

    /**
     * Upon receiving a FloodMessage that it sees for the First time, the flood
     * component sends it to all its neighbors. When the flood component has
     * received the same FloodMessage from every neighbor, it triggers to the
     * application a FloodDoneEvent.
     *
     * @param event
     */
    public void handleFloodMessage(FloodMessage event) {
        NodeReference srcNodeRef = event.getSource();
        System.out.printf("receive a message %s from node %d", event.getMessage(), srcNodeRef.getId());
//        FloodDoneEvent floodDoneEvent = new FloodDoneEvent(event.getMessage());
//        component.raiseEvent(floodDoneEvent);
        // get all neighbours
        //topologyDescriptor.getAllOtherNodes();
    }
}
