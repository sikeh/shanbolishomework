package assignment2.smtp;

/**
 * Created by IntelliJ IDEA.
 * User: Sike Huang
 * Date: 2008-3-31
 * Time: 19:45:35
 * To change this template use File | Settings | File Templates.
 */
public class SmtpException extends Exception {
    public SmtpException(String message) {
        super(message);
    }
}
