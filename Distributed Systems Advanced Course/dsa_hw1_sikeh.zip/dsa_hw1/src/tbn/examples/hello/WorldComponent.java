package tbn.examples.hello;

import tbn.api.Component;

public class WorldComponent {

	private final Component component;
	
	public WorldComponent(Component component) {
		this.component = component;
	}
	
	public void handleHelloEvent(HelloEvent event) {
		String message = event.getMessage();
		
		System.out.println("World: I got message: \"" + message + "\"");
		
		component.raiseEvent(new ResponseEvent("Hi there!"));
		
		System.out.println("World: I replied: Hi there!");
	}
}
