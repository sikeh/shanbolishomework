package tbn.examples.hello;

import tbn.api.Event;

public class ResponseEvent implements Event {
	private final String message;

	public ResponseEvent(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
